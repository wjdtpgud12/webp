<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# 길잡이별

방문자가 이 학생 개발자를 알게 되고 그에게 연락한다

## 지표

매월 문의하기 폼을 제출한 방문자 수
